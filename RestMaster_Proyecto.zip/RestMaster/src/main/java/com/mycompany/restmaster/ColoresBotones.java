package com.mycompany.restmaster;


import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
        
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class ColoresBotones implements MouseListener {
 
    private final MenuPrincipalp view;

   // ColoresBotones(MenuPrincipalp aThis) {
     //   throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}

    public final  void events(){
    view.btnReservarMesas.addMouseListener(this);
    view.btnRegistrarCliente.addMouseListener(this);
    view.btnInventario.addMouseListener(this);
    view.btnConfi.addMouseListener(this);
  
    
}
    public ColoresBotones(MenuPrincipalp view){
        this.view=view;
        events();
      
    }
       @Override
    public void mouseClicked(MouseEvent me) {
        
    }

    @Override
    public void mousePressed(MouseEvent me) {
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
    }

    @Override
    public void mouseEntered(MouseEvent me) {
       Object evt=me.getSource();
       
       if(evt.equals(view.btnReservarMesas)){
           changeColor(view.Pmesas, new Color(131,193,0));
           
       }else if(evt.equals(view.btnRegistrarCliente)){
            changeColor(view.PregisClientes, new Color(131,193,0));
       }else if(evt.equals(view.btnInventario)){
            changeColor(view.PanelInventario, new Color(131,193,0));
       }else if (evt.equals(view.btnConfi)){
            changeColor(view.PanelConfiguracion, new Color(131,193,0));
       }
    }

    @Override
    public void mouseExited(MouseEvent me) {
        Object evt=me.getSource();
        
        if(evt.equals(view.btnReservarMesas)){
             changeColor(view.Pmesas, new Color(102,153,0));
       }else if(evt.equals(view.btnRegistrarCliente)){
            changeColor(view.PregisClientes, new Color(102,153,0));
       }else if(evt.equals(view.btnInventario)){
             changeColor(view.PanelInventario, new Color(102,153,0));
       }else if (evt.equals(view.btnConfi)){
            changeColor(view.PanelConfiguracion, new Color(102,153,0));
       }
    }
    
    private void changeColor(JPanel panel, Color color){
        panel.setBackground(color);
    }
}
