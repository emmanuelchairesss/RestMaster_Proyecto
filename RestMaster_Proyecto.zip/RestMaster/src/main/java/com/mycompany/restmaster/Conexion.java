/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.restmaster;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;



/**
 *
 * @author LENOVO
 */

public class Conexion {
    Connection conectar=null;
    String usuario="emma1";
    String contrasena="1976";
    String bd="prueba_sqlnet";
    String ip="localhost";
    String puerto="1433";
    
  String cadena = "jdbc:sqlserver://localhost:1433;databaseName=RestMaster;user=emma1;password=1976;encrypt=true;trustServerCertificate=true;";


    
    public Connection establecerConexion(){
    try{
        String cadena = "jdbc:sqlserver://localhost:1433;databaseName=RestMaster;user=emma1;password=1976;encrypt=true;trustServerCertificate=true;";


        conectar=DriverManager.getConnection(cadena,usuario,contrasena);
        System.out.println("Se conecto Correctamente");
       // JOptionPane.showMessageDialog(null,"Se conecto correctamente");
        
    }catch(Exception e){
        JOptionPane.showMessageDialog(null,"Error en conectar a la base de datos: "+ e.toString());
    }
    
    return conectar;
}
}


