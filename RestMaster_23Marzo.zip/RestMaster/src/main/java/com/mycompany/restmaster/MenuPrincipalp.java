package com.mycompany.restmaster;


import Pantallas.RegistratAsistencia;
import Pantallas.Inventario;
import Pantallas.PrincipalInicio;
import Pantallas.VerHistorialClientes;
import Pantallas.ReservarMesas;
import java.awt.BorderLayout;
import java.awt.Color;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.swing.text.AbstractDocument.Content;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MenuPrincipalp extends javax.swing.JFrame {
public ColoresBotones colb;
    /**
     * Creates new form MenuPrincipalp
     */
    public MenuPrincipalp() {
        initComponents();
        this.setLocationRelativeTo(null);
        colb = new ColoresBotones(this);
       Date();
        
       
    }
public void Date(){
    
   LocalDate now=LocalDate.now();
   Locale spanishLocale=new Locale("es","ES");
   fecha.setText(now.format(DateTimeFormatter.ofPattern("'Hoy es' EEEE dd 'de' MMMM 'de' yyyy",spanishLocale)));
   
//        int year =now.getYear();
//        int dia= now.getDayOfMonth();
//        int month= now.getMonthValue();
//        String[] meses={"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
//        fecha.setText("Hoy es "+dia+" de "+meses[month -1]+" de "+year);
}
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelPrincipal = new javax.swing.JPanel();
        PanelMenu = new javax.swing.JPanel();
        lblRestMaster = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        PregisClientes = new javax.swing.JPanel();
        btnRegistrarCliente = new javax.swing.JButton();
        PanelInventario = new javax.swing.JPanel();
        btnInventario = new javax.swing.JButton();
        PanelConfiguracion = new javax.swing.JPanel();
        btnConfi = new javax.swing.JButton();
        Pmesas = new javax.swing.JPanel();
        btnReservarMesas = new javax.swing.JButton();
        PanelFondo = new javax.swing.JPanel();
        Pcerrar = new javax.swing.JPanel();
        lblCerrar = new javax.swing.JLabel();
        fecha = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        PanelTodos = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        PanelPrincipal.setBackground(new java.awt.Color(255, 255, 255));

        PanelMenu.setBackground(new java.awt.Color(100, 160, 0));

        lblRestMaster.setFont(new java.awt.Font("SimSun-ExtB", 1, 36)); // NOI18N
        lblRestMaster.setForeground(new java.awt.Color(255, 255, 255));
        lblRestMaster.setText("Rest Master");

        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));

        PregisClientes.setBackground(new java.awt.Color(102, 153, 0));

        btnRegistrarCliente.setFont(new java.awt.Font("Roboto Condensed Black", 1, 18)); // NOI18N
        btnRegistrarCliente.setForeground(new java.awt.Color(255, 255, 255));
        btnRegistrarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagen/profile_5765536.png"))); // NOI18N
        btnRegistrarCliente.setText("Ver Historial de Clientes");
        btnRegistrarCliente.setBorder(null);
        btnRegistrarCliente.setBorderPainted(false);
        btnRegistrarCliente.setContentAreaFilled(false);
        btnRegistrarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnRegistrarCliente.setFocusPainted(false);
        btnRegistrarCliente.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRegistrarCliente.setIconTextGap(20);
        btnRegistrarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarClienteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PregisClientesLayout = new javax.swing.GroupLayout(PregisClientes);
        PregisClientes.setLayout(PregisClientesLayout);
        PregisClientesLayout.setHorizontalGroup(
            PregisClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PregisClientesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnRegistrarCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        PregisClientesLayout.setVerticalGroup(
            PregisClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnRegistrarCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
        );

        PanelInventario.setBackground(new java.awt.Color(102, 153, 0));

        btnInventario.setBackground(new java.awt.Color(102, 153, 0));
        btnInventario.setFont(new java.awt.Font("Roboto Condensed Black", 1, 18)); // NOI18N
        btnInventario.setForeground(new java.awt.Color(255, 255, 255));
        btnInventario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagen/schedule_8646480.png"))); // NOI18N
        btnInventario.setText("Inventario");
        btnInventario.setBorder(null);
        btnInventario.setBorderPainted(false);
        btnInventario.setContentAreaFilled(false);
        btnInventario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnInventario.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnInventario.setIconTextGap(20);
        btnInventario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInventarioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelInventarioLayout = new javax.swing.GroupLayout(PanelInventario);
        PanelInventario.setLayout(PanelInventarioLayout);
        PanelInventarioLayout.setHorizontalGroup(
            PanelInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelInventarioLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnInventario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelInventarioLayout.setVerticalGroup(
            PanelInventarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnInventario, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
        );

        PanelConfiguracion.setBackground(new java.awt.Color(102, 153, 0));

        btnConfi.setBackground(new java.awt.Color(102, 153, 0));
        btnConfi.setFont(new java.awt.Font("Roboto Condensed Black", 1, 18)); // NOI18N
        btnConfi.setForeground(new java.awt.Color(255, 255, 255));
        btnConfi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagen/tick-mark (1).png"))); // NOI18N
        btnConfi.setText("Registrar Asistencia");
        btnConfi.setBorder(null);
        btnConfi.setBorderPainted(false);
        btnConfi.setContentAreaFilled(false);
        btnConfi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnConfi.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnConfi.setIconTextGap(20);
        btnConfi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelConfiguracionLayout = new javax.swing.GroupLayout(PanelConfiguracion);
        PanelConfiguracion.setLayout(PanelConfiguracionLayout);
        PanelConfiguracionLayout.setHorizontalGroup(
            PanelConfiguracionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelConfiguracionLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnConfi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelConfiguracionLayout.setVerticalGroup(
            PanelConfiguracionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnConfi, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
        );

        Pmesas.setBackground(new java.awt.Color(102, 153, 0));

        btnReservarMesas.setBackground(new java.awt.Color(120, 170, 0));
        btnReservarMesas.setFont(new java.awt.Font("Roboto Condensed Black", 1, 18)); // NOI18N
        btnReservarMesas.setForeground(new java.awt.Color(255, 255, 255));
        btnReservarMesas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagen/mesa (1).png"))); // NOI18N
        btnReservarMesas.setText("Reservar Mesas");
        btnReservarMesas.setBorder(null);
        btnReservarMesas.setBorderPainted(false);
        btnReservarMesas.setContentAreaFilled(false);
        btnReservarMesas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnReservarMesas.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnReservarMesas.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnReservarMesas.setIconTextGap(20);
        btnReservarMesas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnReservarMesasMouseClicked(evt);
            }
        });
        btnReservarMesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservarMesasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PmesasLayout = new javax.swing.GroupLayout(Pmesas);
        Pmesas.setLayout(PmesasLayout);
        PmesasLayout.setHorizontalGroup(
            PmesasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PmesasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnReservarMesas, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PmesasLayout.setVerticalGroup(
            PmesasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PmesasLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnReservarMesas, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout PanelMenuLayout = new javax.swing.GroupLayout(PanelMenu);
        PanelMenu.setLayout(PanelMenuLayout);
        PanelMenuLayout.setHorizontalGroup(
            PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PregisClientes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PanelInventario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PanelConfiguracion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Pmesas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblRestMaster))
                .addGap(19, 19, 19))
        );
        PanelMenuLayout.setVerticalGroup(
            PanelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMenuLayout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(lblRestMaster)
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(127, 127, 127)
                .addComponent(Pmesas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(PregisClientes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PanelInventario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PanelConfiguracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(366, Short.MAX_VALUE))
        );

        PanelFondo.setBackground(new java.awt.Color(153, 204, 0));

        Pcerrar.setBackground(new java.awt.Color(153, 204, 0));
        Pcerrar.setForeground(new java.awt.Color(102, 153, 0));

        lblCerrar.setBackground(new java.awt.Color(153, 204, 0));
        lblCerrar.setFont(new java.awt.Font("Roboto Condensed Light", 1, 36)); // NOI18N
        lblCerrar.setText("  X");
        lblCerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCerrarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblCerrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblCerrarMouseExited(evt);
            }
        });

        javax.swing.GroupLayout PcerrarLayout = new javax.swing.GroupLayout(Pcerrar);
        Pcerrar.setLayout(PcerrarLayout);
        PcerrarLayout.setHorizontalGroup(
            PcerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PcerrarLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        PcerrarLayout.setVerticalGroup(
            PcerrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PcerrarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCerrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        fecha.setFont(new java.awt.Font("Roboto SemiCondensed ExtraLight", 1, 24)); // NOI18N
        fecha.setForeground(new java.awt.Color(255, 255, 255));
        fecha.setText("Hoy es {dayname} {day} de {month} de {year}");

        jLabel2.setFont(new java.awt.Font("Roboto SemiCondensed ExtraLight", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Bienvenido !");

        javax.swing.GroupLayout PanelFondoLayout = new javax.swing.GroupLayout(PanelFondo);
        PanelFondo.setLayout(PanelFondoLayout);
        PanelFondoLayout.setHorizontalGroup(
            PanelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelFondoLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(PanelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 534, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 631, Short.MAX_VALUE)
                .addComponent(Pcerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        PanelFondoLayout.setVerticalGroup(
            PanelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelFondoLayout.createSequentialGroup()
                .addGroup(PanelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Pcerrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fecha)
                .addContainerGap(76, Short.MAX_VALUE))
        );

        PanelTodos.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout PanelTodosLayout = new javax.swing.GroupLayout(PanelTodos);
        PanelTodos.setLayout(PanelTodosLayout);
        PanelTodosLayout.setHorizontalGroup(
            PanelTodosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        PanelTodosLayout.setVerticalGroup(
            PanelTodosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout PanelPrincipalLayout = new javax.swing.GroupLayout(PanelPrincipal);
        PanelPrincipal.setLayout(PanelPrincipalLayout);
        PanelPrincipalLayout.setHorizontalGroup(
            PanelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelPrincipalLayout.createSequentialGroup()
                .addComponent(PanelMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(PanelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PanelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(PanelPrincipalLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(PanelTodos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        PanelPrincipalLayout.setVerticalGroup(
            PanelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addComponent(PanelMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelPrincipalLayout.createSequentialGroup()
                .addComponent(PanelFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PanelTodos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelPrincipal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnReservarMesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservarMesasActionPerformed
      ReservarMesas p = new ReservarMesas();
    
    p.setSize(1260, 734);
    p.setLocation(0, 0);
    
    // Asegúrate de agregarlo al contenedor adecuado
    PanelTodos.removeAll();  // Elimina cualquier componente anterior en PanelFondo
    PanelTodos.add(p, BorderLayout.CENTER);  // Agrega p al PanelFondo (o el contenedor adecuado)
    
    //Actualiza la interfaz de usuario
    PanelTodos.revalidate();
    PanelTodos.repaint();

    }//GEN-LAST:event_btnReservarMesasActionPerformed

    private void btnInventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInventarioActionPerformed
         Inventario p = new Inventario();
    
    p.setSize(1352, 691);
    p.setLocation(0, 0);
    
    PanelTodos.removeAll(); 
    PanelTodos.add(p, BorderLayout.CENTER);
    PanelTodos.revalidate();
    PanelTodos.repaint();
    }//GEN-LAST:event_btnInventarioActionPerformed

    private void btnConfiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfiActionPerformed
         RegistratAsistencia p = new RegistratAsistencia();
    
    p.setSize(1352, 691);
    p.setLocation(0, 0);
  
 
    PanelTodos.removeAll();  
    PanelTodos.add(p, BorderLayout.CENTER);
    PanelTodos.revalidate();
    PanelTodos.repaint();
    }//GEN-LAST:event_btnConfiActionPerformed

    private void btnRegistrarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarClienteActionPerformed
      VerHistorialClientes p = new VerHistorialClientes();
    
   p.setSize(1352, 691);
    p.setLocation(0, 0);
    

    PanelTodos.removeAll();  
    PanelTodos.add(p, BorderLayout.CENTER); 
    PanelTodos.revalidate();
    PanelTodos.repaint();
    }//GEN-LAST:event_btnRegistrarClienteActionPerformed

    private void lblCerrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCerrarMouseExited
         Pcerrar.setBackground(new Color(153,204,0));
        lblCerrar.setBackground(new Color(153,204,0));
    }//GEN-LAST:event_lblCerrarMouseExited

    private void lblCerrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCerrarMouseClicked
      System.exit(0);
    }//GEN-LAST:event_lblCerrarMouseClicked

    private void lblCerrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCerrarMouseEntered
        Pcerrar.setBackground(Color.red);
         lblCerrar.setBackground(Color.white);
    }//GEN-LAST:event_lblCerrarMouseEntered

    private void btnReservarMesasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReservarMesasMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnReservarMesasMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipalp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipalp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipalp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipalp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipalp().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JPanel PanelConfiguracion;
    private javax.swing.JPanel PanelFondo;
    public javax.swing.JPanel PanelInventario;
    private javax.swing.JPanel PanelMenu;
    private javax.swing.JPanel PanelPrincipal;
    private javax.swing.JPanel PanelTodos;
    private javax.swing.JPanel Pcerrar;
    public javax.swing.JPanel Pmesas;
    public javax.swing.JPanel PregisClientes;
    public javax.swing.JButton btnConfi;
    public javax.swing.JButton btnInventario;
    public javax.swing.JButton btnRegistrarCliente;
    public javax.swing.JButton btnReservarMesas;
    private javax.swing.JLabel fecha;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblCerrar;
    private javax.swing.JLabel lblRestMaster;
    // End of variables declaration//GEN-END:variables
}
