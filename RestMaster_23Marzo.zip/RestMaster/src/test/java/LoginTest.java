
import com.mycompany.restmaster.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.*;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LENOVO
 */
public class LoginTest {

     /**
 * Test para verificar si la conexión a la base de datos se realiza correctamente.
 */
@Test
public void testConexionCorrecta() {
    Conexion conexion = new Conexion();
    Connection con = conexion.establecerConexion();
    assertNotNull("La conexión no debería ser nula", con);
}

/**
 * Test para verificar si un login con usuario y contraseña correctos se valida correctamente.
 * Se utiliza el usuario "Gerente" y la contraseña "123", y también se verifica el login para el "Recepcionista" con la contraseña "456".
 */
@Test
public void testLoginCorrecto() {
    //Gerente
    String usuarioGerente = "Gerente";
    String contrasenaGerente = "123";

    String sql = "SELECT * FROM login WHERE Nombre = ? AND Contrasena = ?";

    try (Connection con = new Conexion().establecerConexion();
         PreparedStatement pst = con.prepareStatement(sql)) {

        
        pst.setString(1, usuarioGerente);
        pst.setString(2, contrasenaGerente);
        ResultSet rs = pst.executeQuery();
        assertTrue("El usuario Gerente debe existir", rs.next());
        String nombreUsuario = rs.getString("Nombre");
        String contrasenaUsuario = rs.getString("Contrasena");

        System.out.println("Nombre de usuario de la base de datos: " + nombreUsuario);
        System.out.println("Contraseña de la base de datos: " + contrasenaUsuario);

        assertTrue("El nombre de usuario debe ser Gerente", usuarioGerente.trim().equalsIgnoreCase(nombreUsuario.trim()));
        assertTrue("La contraseña debe ser 123", contrasenaGerente.trim().equals(contrasenaUsuario.trim()));

        // Recepcionista
        String usuarioRecepcionista = "Recepcionista";
        String contrasenaRecepcionista = "456";

        pst.setString(1, usuarioRecepcionista);
        pst.setString(2, contrasenaRecepcionista);
        rs = pst.executeQuery();
        assertTrue("El usuario Recepcionista debe existir", rs.next());
        nombreUsuario = rs.getString("Nombre");
        contrasenaUsuario = rs.getString("Contrasena");

        System.out.println("Nombre de usuario de la base de datos: " + nombreUsuario);
        System.out.println("Contraseña de la base de datos: " + contrasenaUsuario);

        assertTrue("El nombre de usuario debe ser Recepcionista", usuarioRecepcionista.trim().equalsIgnoreCase(nombreUsuario.trim()));
        assertTrue("La contraseña debe ser 456", contrasenaRecepcionista.trim().equals(contrasenaUsuario.trim()));

    } catch (SQLException e) {
        fail("Error al ejecutar la consulta: " + e.getMessage());
    }
}

/**
 * Test para verificar que un login con usuario correcto pero contraseña incorrecta 
 * no valide el acceso.
 * Se valida tanto para "Gerente" como para "Recepcionista" con contraseñas incorrectas.
 */
@Test
public void testLoginIncorrecto() {
  
    String usuarioGerente = "Gerente";
    String contrasenaGerente = "wrong_password";

    String sql = "SELECT * FROM login WHERE Nombre = ? AND Contrasena = ?";

    try (Connection con = new Conexion().establecerConexion();
         PreparedStatement pst = con.prepareStatement(sql)) {

       
        pst.setString(1, usuarioGerente);
        pst.setString(2, contrasenaGerente);
        ResultSet rs = pst.executeQuery();
        assertFalse("El usuario Gerente no debe existir con la contraseña incorrecta", rs.next());

      
        String usuarioRecepcionista = "Recepcionista";
        String contrasenaRecepcionista = "wrong_password";
        
        pst.setString(1, usuarioRecepcionista);
        pst.setString(2, contrasenaRecepcionista);
        rs = pst.executeQuery();
        assertFalse("El usuario Recepcionista no debe existir con la contraseña incorrecta", rs.next());

    } catch (SQLException e) {
        fail("Error al ejecutar la consulta: " + e.getMessage());
    }
}

/**
 * Test para verificar que un usuario no registrado en la base de datos no puede acceder 
 * al sistema.
 * Se verifica que tanto "Gerente" como "Recepcionista" no existan si no están registrados.
 */
@Test
public void testUsuarioNoRegistrado() {
   
    String usuario = "UsuarioInexistente";
    String contrasena = "123";

    String sql = "SELECT * FROM login WHERE Nombre = ? AND Contrasena = ?";

    try (Connection con = new Conexion().establecerConexion();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, usuario);
        pst.setString(2, contrasena);
        ResultSet rs = pst.executeQuery();
        assertFalse("El usuario no debe existir", rs.next());

      
        String usuarioRecepcionista = "UsuarioInexistente";
        String contrasenaRecepcionista = "456";

        pst.setString(1, usuarioRecepcionista);
        pst.setString(2, contrasenaRecepcionista);
        rs = pst.executeQuery();
        assertFalse("El usuario Recepcionista no debe existir", rs.next());

    } catch (SQLException e) {
        fail("Error al ejecutar la consulta: " + e.getMessage());
    }
}

/**
 * Test para verificar la existencia de la base de datos y su conexión.
 * Este test verifica que la conexión a la base de datos se establezca correctamente.
 */
@Test
public void testExistenciaBaseDeDatos() {
    Conexion conexion = new Conexion();
    try (Connection con = conexion.establecerConexion()) {
        assertNotNull("La base de datos debe existir y la conexión debe ser exitosa", con);
    } catch (SQLException e) {
        fail("No se pudo conectar a la base de datos: " + e.getMessage());
    }
}

/**
 * Test para verificar que la conexión se cierra correctamente.
 * Este test valida que la conexión a la base de datos se cierre correctamente.
 */
@Test
public void testCerrarConexion() {
    Conexion conexion = new Conexion();
    try (Connection con = conexion.establecerConexion()) {
        assertNotNull("La conexión debe haberse establecido", con);
        conexion.cerrarConexion(); // Intentamos cerrar la conexión
        assertTrue("La conexión debe cerrarse correctamente", con.isClosed());
    } catch (SQLException e) {
        fail("Error al cerrar la conexión: " + e.getMessage());
    }
}
}
