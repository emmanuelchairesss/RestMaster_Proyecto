/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


import Pantallas.ReservarMesas;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.awt.Color;
import javax.swing.JButton;
import java.util.HashMap;


/**
 *
 * @author Edith Ramirez
 */
public class ReservarMesasTest {
    
    private ReservarMesas reservarMesas;
    private HashMap<JButton, String> estadosMesas;
    private JButton mesa1;

    
    @BeforeEach
    public void setUp() {
        reservarMesas = new ReservarMesas();
        estadosMesas = reservarMesas.getEstadosMesas();
        mesa1 = reservarMesas.getEstadosMesas().keySet().iterator().next();
    }

    // Caso 1: Verificar que la mesa comienza con estado "disponible"
    @Test
    public void testMesaDisponible() {
        assertEquals("disponible", estadosMesas.get(mesa1), "La mesa debería estar disponible inicialmente");
        assertEquals(Color.GREEN.getRGB(), mesa1.getBackground().getRGB(), "El color de fondo de la mesa debe ser verde (disponible)");
    }


    // Caso 2: Probar que se puede seleccionar una mesa disponible
    @Test
    public void testSeleccionarMesaDisponible() {
        reservarMesas.seleccionarMesa(mesa1);
        assertNotNull(reservarMesas.getMesaSeleccionada(), "La mesa seleccionada debería ser diferente de null");
        assertEquals(mesa1, reservarMesas.getMesaSeleccionada(), "La mesa seleccionada debería ser la Mesa 1");
    }

    // Caso 3: Cambiar estado de una mesa a "ocupada"
    @Test
    public void testCambiarEstadoMesaOcupada() {
        reservarMesas.seleccionarMesa(mesa1);
        reservarMesas.cambiarEstadoMesa("ocupada", Color.RED);
        assertEquals("ocupada", estadosMesas.get(mesa1), "El estado de la mesa debería cambiar a 'ocupada'");
        assertEquals(Color.RED, mesa1.getBackground(), "El color de fondo de la mesa debe ser rojo (ocupada)");
    }

    // Caso 4: Verificar que el botón de reservar se habilite cuando se selecciona una mesa disponible
    @Test
    public void testResaltarBotonReservar() {
        reservarMesas.seleccionarMesa(mesa1);
        assertTrue(reservarMesas.getBtnReservarMesa().isEnabled(), "El botón de reservar debería estar habilitado cuando se selecciona una mesa disponible");
    }

    // Caso 5: Verificar que el estado de la mesa no cambie si la mesa no está disponible
    @Test
    public void testNoCambiarEstadoMesaNoDisponible() {
        // Cambiar estado de la mesa a "reservada"
        estadosMesas.put(mesa1, "reservada");
        // Intentar cambiar estado a "ocupada"
        reservarMesas.seleccionarMesa(mesa1);
        reservarMesas.cambiarEstadoMesa("ocupada", Color.RED);
        assertEquals("reservada", estadosMesas.get(mesa1), "El estado de la mesa no debería cambiar si ya está reservada");
    }

    // Caso 6: Verificar que las mesas se muestren correctamente según el estado
    @Test
    public void testMostrarMesasPorEstado() {
        JButton[] mesas = reservarMesas.getEstadosMesas().keySet().toArray(new JButton[0]);
        estadosMesas.put(mesas[1], "ocupada");
        estadosMesas.put(mesas[2], "reservada");

        reservarMesas.mostrarMesasPorEstado("disponible");
        assertTrue(mesas[0].isVisible(), "La Mesa 1 debería ser visible");
        assertFalse(mesas[1].isVisible(), "La Mesa 2 no debería ser visible");
        assertFalse(mesas[2].isVisible(), "La Mesa 3 no debería ser visible");
    }


    // Caso 7: Probar que se muestran todas las mesas cuando se hace clic en el botón 'Mostrar Todas'
    @Test
    public void testMostrarTodasLasMesas() {
        JButton mesa2 = new JButton("Mesa 2");
        estadosMesas.put(mesa2, "ocupada");
        JButton mesa3 = new JButton("Mesa 3");
        estadosMesas.put(mesa3, "reservada");

        reservarMesas.mostrarTodasLasMesas();
        assertTrue(mesa1.isVisible(), "La Mesa 1 debería ser visible");
        assertTrue(mesa2.isVisible(), "La Mesa 2 debería ser visible");
        assertTrue(mesa3.isVisible(), "La Mesa 3 debería ser visible");
    }
   
  }